# Vaultline ATM — Secure Withdrawal Prototype

A front-end prototype of an ATM cash-withdrawal flow that supports **four interchangeable
authentication methods** — the user can verify their identity with *any one* of:

- 🔢 **PIN** — 4-digit keypad entry
- 👆 **Fingerprint** — simulated biometric scan
- 🙂 **Face ID** — simulated camera-based face verification
- 📱 **OTP** — 6-digit one-time code sent to a registered mobile number

Once verified, the user selects a withdrawal amount, confirms the transaction, and watches a
simulated cash-dispensing sequence.

**[Live demo →](#)** *(enable GitHub Pages — see below)*

## Features

- Single self-contained HTML file — no build step, no dependencies to install
- Four working authentication simulations (PIN validation + lockout, fingerprint scan
  animation, face scan animation, OTP with countdown/resend)
- Four-stage transaction progress indicator (Card → Verify → Amount → Cash)
- Fully responsive, keyboard-accessible, respects `prefers-reduced-motion`
- Cash-dispensing and receipt visuals on success

## Getting started

Clone the repo and open `index.html` in any browser — that's it.

```bash
git clone https://github.com/<your-username>/vaultline-atm.git
cd vaultline-atm
open index.html   # or just double-click the file
```

## Demo credentials

Since this is a front-end-only prototype (no backend), a few methods use fixed demo values:

| Method | Demo value |
|---|---|
| PIN | `4821` |
| OTP | shown on screen at the OTP step |
| Fingerprint / Face ID | always succeed after the scan animation |

## Project structure

```
vaultline-atm/
├── index.html      # entire app: markup, styles, and logic
├── README.md
└── LICENSE
```

## Deploying with GitHub Pages

1. Push this repo to GitHub.
2. Go to **Settings → Pages**.
3. Under "Build and deployment", set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`.
4. Your live demo will be at `https://<your-username>.github.io/vaultline-atm/`.

## Roadmap / ideas for a real backend

This is a UX prototype only — nothing is sent to a server. To make it production-real you'd add:

- A backend API for card/account lookup and balance/ledger updates
- Real biometric capture (WebAuthn for fingerprint, a vendor SDK for face match)
- An SMS provider (e.g. Twilio) for real OTP delivery
- Session/token-based auth and encrypted transport (this is a bank app — TLS + strict auth is non-negotiable)

## License

MIT — see [LICENSE](LICENSE).
